
from django.db import models
from django.contrib.auth.models import User

class Post(models.Model):
    title = models.CharField(max_length=200)  # Title of the post
    content = models.TextField()  # Content of the post
    published_date = models.DateTimeField()  # Publication date
    author = models.ForeignKey(User, on_delete=models.CASCADE)  # ForeignKey to User model

    def __str__(self):
        """Return the title of the post."""
        return self.title

