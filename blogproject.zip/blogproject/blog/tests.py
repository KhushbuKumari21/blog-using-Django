from django.test import TestCase
from django.contrib.auth.models import User
from .models import Post
from django.utils import timezone
from django.urls import reverse

class PostModelTests(TestCase):

    def setUp(self):
        """Create a user and a post for testing."""
        self.user = User.objects.create_user(username='testuser', password='password')
        self.post = Post.objects.create(
            title='Test Post',
            content='This is a test post.',
            published_date=timezone.now(),
            author=self.user
        )

    def test_post_str(self):
        """Test the __str__ method of the Post model."""
        self.assertEqual(str(self.post), 'Test Post')

class PostViewsTests(TestCase):

    def setUp(self):
        """Create a user and a post for testing views."""
        self.user = User.objects.create_user(username='testuser', password='password')
        self.post = Post.objects.create(
            title='Test Post',
            content='This is a test post.',
            published_date=timezone.now(),
            author=self.user
        )

    def test_post_list_view(self):
        """Test the post list view."""
        response = self.client.get(reverse('post_list'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'blog/post_list.html')
        self.assertContains(response, 'Test Post')

    def test_post_detail_view(self):
        """Test the post detail view."""
        response = self.client.get(reverse('post_detail', args=[self.post.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'blog/post_detail.html')
        self.assertContains(response, 'Test Post')
        self.assertContains(response, 'This is a test post.')
